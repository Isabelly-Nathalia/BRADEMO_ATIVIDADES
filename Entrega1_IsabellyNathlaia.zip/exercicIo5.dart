import 'dart:io';

class House {
  int id;
  String name;
  double price;

  House(this.id, this.name, this.price);
}

void main() {

  List<House> casas = [];

  
  for (int i = 1; i <= 3; i++) {

    print("Cadastro$i");
    print("ID da casa: ");
    int id = int.parse(stdin.readLineSync()!);
    print("Nome da casa: ");
    String nome = stdin.readLineSync()!;
    print ("Preço da casa: ");
    double preco = double.parse(stdin.readLineSync()!);
    casas.add(House(id, nome, preco));
  }
  
  for (var casa in casas) {
    casa..name = "${casa.name} (Cadastrada)";
  }

  for (var casa in casas) {
    print("ID: ${casa.id}");
    print("Nome: ${casa.name}");
    print("Preço: R\$ ${casa.price}");
    print("-|-|-|-|-|-|-|-|-|-");
  }
}