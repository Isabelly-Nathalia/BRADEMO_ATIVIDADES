void main() {
  var equipamento = "Computador";
  String local = "Sala A405";

  dynamic patrimonio = 12345;
  //conferencia do tipo do patrimonio antes da alteração
  print("O patriônio é String? ${patrimonio is String}");

  //alterando o tipo de patrimonio
  patrimonio = "12345-A";

  print("Equipamento: $equipamento");
  print("Local: $local");
  print("Patrimônio: $patrimonio");

  print("O equipamento é String? ${equipamento is String}");
  print("O local é String? ${local is String}");
  print("E agora, o patrimônio é String? ${patrimonio is String}");
}

// é permitido alterar o patrimonio por conta do dynamic, quando é definido inteiro ou string não é possível alterar por conta da pré definição que já foi feita