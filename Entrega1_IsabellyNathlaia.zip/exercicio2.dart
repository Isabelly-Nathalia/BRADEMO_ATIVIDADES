void cadastrarFuncionario({required String nome, String? cargo}) { //required para ser obrigatorio e String? para não ser obrigatorio
  if (cargo != null) { //se tiver o cargo cadastrado
    print("Seja bem-vindo(a) $nome! O seu cargo é $cargo.");
  } else { // se não tiver o cargo cadastrado
    print("Seja bem-vindo(a) $nome!");
  }
}

void main() {
  cadastrarFuncionario(nome: "Ana", cargo: "Analista");
  cadastrarFuncionario(nome: "Carlos");
}