class Laptop {
  late int id;
  late String nome;
  late int ram;
  late double clockCpu;

  Laptop(this.id, this.nome, this.ram, this.clockCpu);

  Laptop.navegacao() {
    id = 1;
    nome = "Laptop básico para navegação na internet: ";
    ram = 4;
    clockCpu = 1.5;
  }

  Laptop.escritorio() {
    id = 2;
    nome = "Laptop médio para escritório: ";
    ram = 8;
    clockCpu = 2.8;
  }

  Laptop.programacao() {
    id = 3;
    nome = "Laptop bom para pogramação: ";
    ram = 16;
    clockCpu = 4.4;
  }
}

void main() {
  var l1 = Laptop.navegacao();
  var l2 = Laptop.escritorio();
  var l3 = Laptop.programacao();

  print("${l1.nome} ${l1.ram}GB RAM e ${l1.clockCpu}GHz de CPU");
  print("${l2.nome} ${l2.ram}GB RAM ${l1.clockCpu}GHz de CPU");
  print("${l3.nome} ${l3.ram}GB RAM ${l1.clockCpu}GHz de CPU");
}