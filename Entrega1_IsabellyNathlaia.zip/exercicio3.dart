class Laptop {
  int id;
  String nome;
  int ram;
  double clockCpu;

  Laptop(this.id, this.nome, this.ram, this.clockCpu);
}

void main() {
  var laptop1 = Laptop(1, "Dell G15", 16, 4.7);
  var laptop2 = Laptop(2, "Lenovo IdeaPad", 16, 3.4);
  var laptop3 = Laptop(3, "Galaxy Book 4", 16, 1.3);

  print("${laptop1.id} - ${laptop1.nome}, memória RAM: ${laptop1.ram}GB e CPU: ${laptop1.clockCpu}GHz");
  print("${laptop2.id} - ${laptop2.nome} - memória RAM: ${laptop2.ram}GB e CPU: ${laptop2.clockCpu}GHz");
  print("${laptop3.id} - ${laptop3.nome} - memória RAM: ${laptop3.ram}GB e CPU: ${laptop3.clockCpu}GHz");
}