import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Insert Image Example'),
          backgroundColor: Colors.blue,
          foregroundColor: Colors.white,
        ),

        body: Column(
          children: [
            const SizedBox(height: 20),
            Center(
              child: SizedBox(
                height: 150,
                width: 220,
                child: Image.network(
                  'https://m.media-amazon.com/images/I/71SXphhivUL._AC_SX679_.jpg',
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(height: 30),
            SizedBox(
              height: 250,
              width: double.infinity,
              child: Image.network(
                'https://images.pexels.com/photos/68507/spring-flowers-flowers-collage-floral-68507.jpeg',
                fit: BoxFit.cover,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
