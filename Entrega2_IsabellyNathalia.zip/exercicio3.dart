import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Stack & Positioned Widget'),
          backgroundColor: Colors.blue,
          foregroundColor: Colors.white,
          centerTitle: true,
        ),

        body: Stack(
          children: <Widget>[
            Positioned(
              top: 60,
              left: 60,
              child: Container(
                width: 180,
                height: 180,
                color: Colors.green,
                padding: EdgeInsets.symmetric(horizontal: 4),
                child: Text("Green", style: TextStyle(color: Colors.white)),
              ),
            ),
            Positioned(
              top: 90,
              left: 90,
              child: Container(
                width: 180,
                height: 180,
                color: Colors.red,
                padding: EdgeInsets.symmetric(horizontal: 4),
                child: Text("Red", style: TextStyle(color: Colors.white)),
              ),
            ),
            Positioned(
              top: 120,
              left: 120,
              child: Container(
                width: 180,
                height: 180,
                color: Colors.purple,
                padding: EdgeInsets.symmetric(horizontal: 4),
                child: Text("Purple", style: TextStyle(color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}