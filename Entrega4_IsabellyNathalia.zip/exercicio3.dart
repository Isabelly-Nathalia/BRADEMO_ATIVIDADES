import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

const big = TextStyle(fontSize: 30);

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Scaffold(
        body: Example26(),
      ),
    );
  }
}

// PASSO 1
class Example1 extends StatelessWidget {
  const Example1({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(color: Colors.red);
  }
}

// PASSO 2
class Example2 extends StatelessWidget {
  const Example2({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(width: 100, height: 100, color: Colors.red);
  }
}

// PASSO 3
class Example3 extends StatelessWidget {
  const Example3({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(width: 100, height: 100, color: Colors.red),
    );
  }
}

// PASSO 4
class Example4 extends StatelessWidget {
  const Example4({super.key});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomRight,
      child: Container(width: 100, height: 100, color: Colors.red),
    );
  }
}

// PASSO 5
class Example5 extends StatelessWidget {
  const Example5({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: double.infinity,
        height: double.infinity,
        color: Colors.red,
      ),
    );
  }
}

// PASSO 6
class Example6 extends StatelessWidget {
  const Example6({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(child: SizedBox());
  }
}

// PASSO 7
class Example7 extends StatelessWidget {
  const Example7({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        color: Colors.red,
        child: Container(color: Colors.green, width: 30, height: 30),
      )
    );
  }
}

// PASSO 8
class Example8 extends StatelessWidget {
  const Example8({super.key});

  @override
  Widget build(BuildContext context) {
    return UnconstrainedBox(
      child: Container(
        padding: const EdgeInsets.all(20),
        color: Colors.red,
        child: Container(color: Colors.green, width: 30, height: 30),
      ),
    );
  }
}

// PASSO 9
class Example9 extends StatelessWidget {
  const Example9({super.key});

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: const BoxConstraints(
        minWidth: 70,
        minHeight: 70,
        maxWidth: 150,
        maxHeight: 150,
      ),
      child: Container(color: Colors.red, width: 10, height: 10),
    );
  }
}

// PASSO 10
class Example10 extends StatelessWidget {
  const Example10({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(
          minWidth: 70,
          minHeight: 70,
          maxWidth: 150,
          maxHeight: 150,
        ),
        child: Container(color: Colors.red, width: 10, height: 10),
      ),
    );
  }
}

// PASSO 11
class Example11 extends StatelessWidget {
  const Example11({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(
          minWidth: 70,
          minHeight: 70,
          maxWidth: 150,
          maxHeight: 150,
        ),
        child: Container(color: Colors.red, width: 1000, height: 1000),
      ),
    );
  }
}

// PASSO 12
class Example12 extends StatelessWidget {
  const Example12({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(
          minWidth: 70,
          minHeight: 70,
          maxWidth: 150,
          maxHeight: 150,
        ),
        child: Container(color: Colors.red, width: 100, height: 100),
      ),
    );
  }
}

// PASSO 13
class Example13 extends StatelessWidget {
  const Example13({super.key});

  @override
  Widget build(BuildContext context) {
    return const UnconstrainedBox(
      child: SizedBox(width: 20, height: 50, child: ColoredBox(color: Colors.red)),
    );
  }
}

// PASSO 14
class Example14 extends StatelessWidget {
  const Example14({super.key});

  @override
  Widget build(BuildContext context) {
    return const UnconstrainedBox(
      child: SizedBox(width: 4000, height: 50, child: ColoredBox(color: Colors.red)),
    );
  }
}

// PASSO 15
class Example15 extends StatelessWidget {
  const Example15({super.key});

  @override
  Widget build(BuildContext context) {
    return const OverflowBox(
      minWidth: 0,
      minHeight: 0,
      maxWidth: double.infinity,
      maxHeight: double.infinity,
      child: SizedBox(width: 4000, height: 50, child: ColoredBox(color: Colors.red)),
    );
  }
}

// PASSO 16
class Example16 extends StatelessWidget {
  const Example16({super.key});

  @override
  Widget build(BuildContext context) {
    return const UnconstrainedBox(
      child: SizedBox(
        width: double.infinity,
        height: 100,
        child: ColoredBox(color: Colors.red),
      ),
    );
  }
}

// PASSO 17
class Example17 extends StatelessWidget {
  const Example17({super.key});

  @override
  Widget build(BuildContext context) {
    return const UnconstrainedBox(
      child: LimitedBox(
        maxWidth: 100,
        child: SizedBox(
          width: double.infinity,
          height: 100,
          child: ColoredBox(color: Colors.red),
        ),
      ),
    );
  }
}

// PASSO 18
class Example18 extends StatelessWidget {
  const Example18({super.key});

  @override
  Widget build(BuildContext context) {
    return const FittedBox(child: Text('Some Example Text.'));
  }
}

// PASSO 19
class Example19 extends StatelessWidget {
  const Example19({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(child: FittedBox(child: Text('Some Example Text.')));
  }
}

// PASSO 20
class Example20 extends StatelessWidget {
  const Example20({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: FittedBox(
        child: Text(
          'This is some very very very large text that is too big to fit a regular screen in a single line.',
        ),
      ),
    );
  }
}

// PASSO 21
class Example21 extends StatelessWidget {
  const Example21({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'This is some very very very large text that is too big to fit a regular screen in a single line.',
      ),
    );
  }
}

// PASSO 22
class Example22 extends StatelessWidget {
  const Example22({super.key});

  @override
  Widget build(BuildContext context) {
    return const FittedBox(
      child: SizedBox(
        height: 20,
        width: double.infinity,
        child: ColoredBox(color: Colors.red),
      ),
    );
  }
}

// PASSO 23
class Example23 extends StatelessWidget {
  const Example23({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(color: Colors.red, child: const Text('Hello!', style: big)),
        Container(color: Colors.green, child: const Text('Goodbye!', style: big)),
      ],
    );
  }
}

// PASSO 24
class Example24 extends StatelessWidget {
  const Example24({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          color: Colors.red,
          child: const Text(
            'This is a very long text that won\'t fit the line.',
            style: big,
          ),
        ),
        Container(color: Colors.green, child: const Text('Goodbye!', style: big)),
      ],
    );
  }
}

// PASSO 25
class Example25 extends StatelessWidget {
  const Example25({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Center(
            child: Container(
              color: Colors.red,
              child: const Text(
                'This is a very long text that won\'t fit the line.',
                style: big,
              ),
            ),
          ),
        ),
        Container(color: Colors.green, child: const Text('Goodbye!', style: big)),
      ],
    );
  }
}

// PASSO 26
class Example26 extends StatelessWidget {
  const Example26({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Container(
            color: Colors.red,
            child: const Text(
              'This is a very long text that won\'t fit the line.',
              style: big,
            ),
          ),
        ),
        Expanded(
          child: Container(
            color: Colors.green,
            child: const Text('Goodbye!', style: big),
          ),
        ),
      ],
    );
  }
}

// PASSO 27
class Example27 extends StatelessWidget {
  const Example27({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Flexible(
          child: Container(
            color: Colors.red,
            child: const Text(
              'This is a very long text that won\'t fit the line.',
              style: big,
            ),
          ),
        ),
        Flexible(
          child: Container(
            color: Colors.green,
            child: const Text('Goodbye!', style: big),
          ),
        ),
      ],
    );
  }
}

// PASSO 28
class Example28 extends StatelessWidget {
  const Example28({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.blue,
        child: const Column(
          children: [Text('Hello!'), Text('Goodbye!')],
        ),
      ),
    );
  }
}

// PASSO 29
class Example29 extends StatelessWidget {
  const Example29({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox.expand(
        child: Container(
          color: Colors.blue,
          child: const Column(
            children: [Text('Hello!'), Text('Goodbye!')],
          ),
        ),
      ),
    );
  }
}