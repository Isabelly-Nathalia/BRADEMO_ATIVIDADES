import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Exercicio1(),
    );
  }
}

class Exercicio1 extends StatelessWidget {
  const Exercicio1({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> items = [
      {
        "titulo": "Begonia\nFlor",
        "imagem": "https://thumbs.dreamstime.com/b/close-up-charming-pink-begonia-flower-begonia-flower-flower-begonia-arbor-plant-genus-malus-rosaceae-315517568.jpg?w=992"
      },
      {
        "titulo": "Magnolia\nFlor",
        "imagem": "https://upload.wikimedia.org/wikipedia/commons/4/49/Magnolia_wieseneri.jpg"
      },
      {
        "titulo": "Girassol\nFlor",
        "imagem": "https://thumbs.dreamstime.com/b/helianthus-annuus-small-potted-sunflowers-dwarf-flower-size-180800610.jpg?w=576"
      },
      {
        "titulo": "Alfazema\nFlor",
        "imagem": "https://thumbs.dreamstime.com/b/flores-da-alfazema-em-um-branco-99382673.jpg"
      },
      {
        "titulo": "Tulipa\nFlor",
        "imagem": "https://thumbs.dreamstime.com/b/spring-flowers-19348634.jpg?w=992"
      },
      {
        "titulo": "Lírio\nFlor",
        "imagem": "https://thumbs.dreamstime.com/z/vistosas-flores-de-un-lirio-dietes-grandiflora-297322191.jpg?ct=jpeg"
      },
    ];

    return Scaffold(
      appBar: AppBar(title: const Text("Exercicio 1")),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GridView.builder(
          itemCount: items.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 0.8,
          ),
          itemBuilder: (context, index) {
            final item = items[index];

            return ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Stack(
                children: [
                  Positioned.fill(
                    child: Image.network(
                      item["imagem"]!,
                      fit: BoxFit.cover,
                    ),
                  ),
                  Positioned.fill(
                    child: Container(
                      color: Colors.black.withOpacity(0.3),
                    ),
                  ),
                  Positioned(
                    left: 10,
                    bottom: 10,
                    child: Text(
                      item["titulo"]!,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}