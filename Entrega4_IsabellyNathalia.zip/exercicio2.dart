import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  } 
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  Widget button(String text) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      margin: const EdgeInsets.symmetric(vertical: 6),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        text,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget language(String text) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 14),
      margin: const EdgeInsets.symmetric(vertical: 6),
      alignment: Alignment.center,
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(color: Colors.white24),
        ),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 16,
        ),
      ),
    );
  }

  Widget header() {
    return const Column(
      children: [
        Text(
          "Responsive Layouts",
          style: TextStyle(color: Colors.white, fontSize: 14),
        ),
        SizedBox(height: 20),
        Text(
          "Cheetah Coding",
          style: TextStyle(
            color: Colors.white,
            fontSize: 26,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 20),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            bool isLandscape = constraints.maxWidth > 600;

            final leftSide = Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                header(),
                button("BUTTON 1"),
                button("BUTTON 2"),
              ],
            );

            final rightSide = Column(
              children: [
                language("Dart"),
                language("JavaScript"),
                language("PHP"),
                language("C++"),
              ],
            );

            return Padding(
              padding: const EdgeInsets.all(16),
              child: isLandscape
                  ? Row(
                      children: [
                        Expanded(child: leftSide),
                        const SizedBox(width: 20),
                        Expanded(child: rightSide),
                      ],
                    )
                  : SingleChildScrollView(
                      child: Column(
                        children: [
                          header(),
                          button("BUTTON 1"),
                          button("BUTTON 2"),
                          const SizedBox(height: 20),
                          language("Dart"),
                          language("JavaScript"),
                          language("PHP"),
                          language("C++"),
                        ],
                      ),
                    ),
            );
          },
        ),
      ),
    );
  }
}