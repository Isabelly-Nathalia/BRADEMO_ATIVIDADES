import 'package:flutter/material.dart';
import 'package:hive_ce/hive.dart';

class Tarefa extends ChangeNotifier {
  List<String> tarefas = [];
  final box = Hive.box("tarefas");

  Tarefa() {
    carregarTarefas();
  }

  void carregarTarefas() {
    tarefas = List<String>.from(
      box.get("lista", defaultValue: [])
    );
    notifyListeners();
  }

  void adicionarTarefas(String tarefa) {
    tarefas.add(tarefa);
    box.put("lista", tarefas);
    notifyListeners();
  }

  void removerTarefas(int index) {
    tarefas.removeAt(index);
    box.put("lista", tarefas);
    notifyListeners();
  }
}