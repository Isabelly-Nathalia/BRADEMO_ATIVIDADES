import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'cont_exercicio2.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => Contador(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Exercicio2(),
      ),
    ),
  );
}

class Exercicio2 extends StatelessWidget {
  const Exercicio2({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Color(0xFFFFE8A3),
        title: Text(
          "Exercício 2 - Contador",
        ),
      ),

      body: Center(
        child: Consumer<Contador>(
          builder: (context, contador, child) {
            return Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Valor do contador",
                  style: TextStyle(
                    fontSize: 25,
                    color: Colors.black,
                  ),
                ),

                SizedBox(height: 15),

                Text(
                  "${contador.valor}",
                  style: TextStyle(
                    fontSize: 65,
                    color: Colors.black,
                  ),
                ),
                SizedBox(height: 35),

                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFFFFD6A5),
                    foregroundColor: Colors.black,
                    minimumSize: Size(180, 50),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                  onPressed: () {
                    contador.incrementar();
                  },
                  child: Text(
                    "Incrementar",
                    style: TextStyle(fontSize: 18),
                  ),
                ),

                SizedBox(height: 15),

                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFFFFD6A5),
                    foregroundColor: Colors.black,
                    minimumSize: Size(180, 50),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                  onPressed: () {
                    contador.decrementar();
                  },
                  child: Text(
                    "Decrementar",
                    style: TextStyle(fontSize: 18),
                  ),
                ),

              ],
            );
          },
        ),
      ),
    );
  }
}