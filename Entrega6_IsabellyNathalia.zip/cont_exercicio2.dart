import 'package:flutter/material.dart';

class Contador extends ChangeNotifier {
  int valor = 0;
  
  void incrementar() {
    valor++;
    notifyListeners();
  }

  void decrementar() {
    valor--;
    notifyListeners();
  }
}