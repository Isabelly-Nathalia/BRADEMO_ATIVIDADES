import 'package:flutter/material.dart';
import 'package:hive_ce/hive.dart';
import 'package:hive_ce_flutter/adapters.dart';

void main() async {

  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await Hive.openBox("config");

  runApp(
    MaterialApp(
      home: MudancadeModo(),
    ),
  );
}

class MudancadeModo extends StatefulWidget {
  const MudancadeModo({super.key});

  @override
  State<MudancadeModo> createState() => _MudancadeModoState();
}

class _MudancadeModoState extends State<MudancadeModo> {
  final box = Hive.box("config");
  bool modoRelax = false;

  @override
  void initState() {
    super.initState();
    modoRelax = box.get("modo", defaultValue: false);
  }
  void trocarModo() {
    setState(() {
      modoRelax = !modoRelax;
      box.put("modo", modoRelax);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          modoRelax ? const Color.fromARGB(255, 97, 141, 177) : const Color.fromARGB(255, 143, 221, 146),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              modoRelax
                  ? "Modo Relax"
                  : "Modo Focado",
              style: TextStyle(
                fontSize: 24,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: trocarModo,
              child: Text("Mudar modo"),
            ),
          ],
        ),
      ),
    );
  }
}