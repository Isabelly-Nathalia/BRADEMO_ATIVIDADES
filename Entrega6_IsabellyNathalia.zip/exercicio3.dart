import 'package:flutter/material.dart';
import 'package:hive_ce_flutter/adapters.dart';
import 'package:provider/provider.dart';
import 'taref_exercicio3.dart';

void main() async {

  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await Hive.openBox("tarefas");

  runApp(
    ChangeNotifierProvider(
      create: (_) => Tarefa(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Exercicio3(),
      ),
    ),
  );
}

class Exercicio3 extends StatelessWidget {
  Exercicio3({super.key});
  final controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFFFFE8A3),
        title: Text(
          "Lista de Tarefas",
          style: TextStyle(
            color: Colors.black,
          ),
        ),
      ),

      body: Consumer<Tarefa>(
        builder: (context, provider, child) {
          return Padding(
            padding: EdgeInsets.all(15),
            child: Column(
              children: [
                TextField(
                  controller: controller,
                  decoration: InputDecoration(
                    labelText: "Nova tarefa",
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                ),

                SizedBox(height: 15),

                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor:Color(0xFFFFE8A3) ,
                      foregroundColor: Colors.black,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                    onPressed: () {
                      if (controller.text.isNotEmpty) {
                        provider.adicionarTarefas(
                          controller.text,
                        );
                        controller.clear();
                      }
                    },
                    child: Text(
                      "Adicionar",
                      style: TextStyle(
                        fontSize: 18,
                      ),
                    ),
                  ),
                ),

                SizedBox(height: 20),

                Expanded(
                  child: ListView.builder(
                    itemCount: provider.tarefas.length,
                    itemBuilder: (context, index) {
                      return Container(
                        margin: EdgeInsets.only(bottom: 10),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: ListTile(
                          title: Text(
                            provider.tarefas[index],
                            style: TextStyle(
                              fontSize: 16,
                            ),
                          ),
                          trailing: IconButton(
                            onPressed: () {
                              provider.removerTarefas(index);
                            },
                            icon: Icon(
                              Icons.remove_circle_outline_rounded,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}