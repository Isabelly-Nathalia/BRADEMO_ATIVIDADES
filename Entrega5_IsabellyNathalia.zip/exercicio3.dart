import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyWidget(),
    );
  }
}

// MODEL
class Post {
  final int id;
  final String title;
  final String body;

  Post({
    required this.id,
    required this.title,
    required this.body,
  });

  factory Post.fromJson(String source) {
    final Map<String, dynamic> json = jsonDecode(source);

    return Post(
      id: json['id'],
      title: json['title'],
      body: json['body'],
    );
  }
}

class MyWidget extends StatefulWidget {
  const MyWidget({super.key});

  @override
  State<MyWidget> createState() => MyState();
}

class MyState extends State<MyWidget> {
  dynamic data;
  bool mostrarResultado = false;

// GET
  Future<void> fetchData() async {
    final response = await http.get(
      Uri.parse('https://jsonplaceholder.typicode.com/posts/1'),
    );

    if (response.statusCode == 200) {
      setState(() {
        data = Post.fromJson(response.body);
        mostrarResultado = true;
      });
    }
  }

// GET LISTA
  Future<void> fetchLista() async {
    final response = await http.get(
      Uri.parse('https://jsonplaceholder.typicode.com/posts'),
    );

    if (response.statusCode == 200) {
      List posts = jsonDecode(response.body);
      String texto = "";
      for (int i = 0; i < 5; i++) {
        texto +=
            "Post ${posts[i]['id']}\n"
            "Titulo: ${posts[i]['title']}\n\n";
      }

      setState(() {
        data = texto;
        mostrarResultado = true;
      });
    }
  }

// POST
  Future<void> criarPost() async {
    final response = await http.post(
      Uri.parse('https://jsonplaceholder.typicode.com/posts'),
      headers: {
        'Content-Type': 'application/json',
      },

      body: jsonEncode({
        'title': 'Novo Post',
        'body': 'Conteudo do novo post',
        'userId': 1,
      }),
    );

    setState(() {
      data = response.body;
      mostrarResultado = true;
    });
  }

// PUT
  Future<void> atualizarPost() async {
    final response = await http.put(
      Uri.parse('https://jsonplaceholder.typicode.com/posts/1'),
      headers: {
        'Content-Type': 'application/json',
      },

      body: jsonEncode({
        'id': 1,
        'title': 'Post Atualizado',
        'body': 'Novo conteudo atualizado',
        'userId': 1,
      }),
    );

    setState(() {
      data = response.body;
      mostrarResultado = true;
    });
  }

// DELETE
  Future<void> deletarPost() async {
    final response = await http.delete(
      Uri.parse('https://jsonplaceholder.typicode.com/posts/1'),
    );

    setState(() {
      data = "DELETE realizado com sucesso!";
      mostrarResultado = true;
    });
  }

// TELA INICIAL
Widget telaInicial() {

  return SingleChildScrollView(
    child: Padding(
      padding: const EdgeInsets.only(top: 40),
      child: Column(
        children: [
          const Text(
            "Exercício 3",
            style: TextStyle(
              fontSize: 24,
            ),
            textAlign: TextAlign.center,
          ),

          const SizedBox(height: 15),

          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Text(
              "Utilizando a API JSONPlaceholder para realizar operacoes HTTP",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
          ),

          const SizedBox(height: 40),

          SizedBox(
            width: 250,
            height: 50,
            child: ElevatedButton(
              onPressed: fetchData,
              child: const Text("GET"),
            ),
          ),

          const SizedBox(height: 15),

          SizedBox(
            width: 250,
            height: 50,
            child: ElevatedButton(
              onPressed: fetchLista,
              child: const Text("GET LISTA"),
            ),
          ),

          const SizedBox(height: 15),

          SizedBox(
            width: 250,
            height: 50,
            child: ElevatedButton(
              onPressed: criarPost,
              child: const Text("POST"),
            ),
          ),

          const SizedBox(height: 15),

          SizedBox(
            width: 250,
            height: 50,
            child: ElevatedButton(
              onPressed: atualizarPost,
              child: const Text("PUT"),
            ),
          ),

          const SizedBox(height: 15),

          SizedBox(
            width: 250,
            height: 50,
            child: ElevatedButton(
              onPressed: deletarPost,
              child: const Text("DELETE"),
            ),
          ),
        ],
      ),
    ),
  );
}

//RESULTADO
Widget telaResultado() {

  return Padding(
    padding: const EdgeInsets.all(16),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        IconButton(
          onPressed: () {
            setState(() {
              mostrarResultado = false;
            });
          },
          icon: const Icon(Icons.arrow_back),
        ),

        const SizedBox(height: 20),

        Expanded(
          child: SingleChildScrollView(
            child: data is Post
                ? Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "ID: ${(data as Post).id}",
                        style: const TextStyle(fontSize: 18),
                      ),

                      const SizedBox(height: 15),

                      Text(
                        (data as Post).title,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      const SizedBox(height: 15),

                      Text(
                        (data as Post).body,
                        style: const TextStyle(fontSize: 18),
                      ),
                    ],
                  )

                : Text(
                    data.toString(),
                    style: const TextStyle(fontSize: 18),
                  ),
          ),
        ),
      ],
    ),
  );
}

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        centerTitle: true,
        title: const Text("Requisições HTTP"),
      ),

      body: mostrarResultado
          ? telaResultado()
          : telaInicial(),
    );
  }
}
